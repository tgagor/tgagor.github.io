<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that other
 * 'pages' on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Thirteen
 * @since Twenty Thirteen 1.0
 * Template Name: HaveFunNew
 */

get_header(); ?>
	<div id="primary" class="content-area">
		<div id="content" class="site-content" role="main">
				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<header class="entry-header">
						<?php if ( has_post_thumbnail() && ! post_password_required() ) : ?>
						<div class="entry-thumbnail">
							<?php the_post_thumbnail(); ?>
						</div>
						<?php endif; ?>
						<h1 class="entry-title"><?php the_title(); ?></h1>
					</header><!-- .entry-header -->

					<div class="entry-content">
					<?php if ( have_posts() ) : ?>
					    <?php the_post(); the_content(); ?>
					    <hr />
					<?php endif; ?>
<?

$link = mysql_connect('localhost', 'wp', 'wppass');
if (!$link) {
        die();
}

mysql_select_db("wp");

function _getrandemail() {
    $login = '';
    $domain = '';
    $domains = array("com", "org", "net", "pl", "org.pl", "com.pl", "uk", "de", "eu");

    for($j=0; $j < rand(10,20); $j++) {
        $login .= chr(rand(97,122));
    }
    for($j=0; $j < rand(10,20); $j++) {
        $domain .= chr(rand(97,122));
    }
    $domain .= '.'.$domains[rand(0, count($domains)-1)];

    return $login.'@'.$domain;
}

function get_poisoned_jokes($count = 2) {
    $posts = array();

    $query = mysql_query('SELECT post_content FROM wp_posts AS r1 JOIN (SELECT (RAND() * (SELECT MAX(id) FROM wp_posts)) AS id) AS r2 WHERE r1.id >= r2.id ORDER BY r1.id ASC LIMIT '. (int)$count);
    if ($query) {
        while($row = mysql_fetch_assoc($query)) {
            $post = strip_tags($row['post_content'], "<br>");
            for($i = 0; $i < rand(5,strlen($post)/5); $i++)
                $post = preg_replace("/(\s+)(\w{4,".rand(5,10)."})(\s+)/m", '$1<a href="mailto:' . _getrandemail() . '">$2</a>$3', $post, 1);
            $posts[] = $post;
        }

        return $posts;
    }
}

foreach ( get_poisoned_jokes() as $joke) {
        print("<p>" . nl2br($joke) . "</p><hr>");
}

mysql_close($link);

?>
		                <p> <a href="?joke=<?=rand()%20?>" class="more-link">Czytaj dalej</a></p>
						<?php wp_link_pages( array( 'before' => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'twentythirteen' ) . '</span>', 'after' => '</div>', 'link_before' => '<span>', 'link_after' => '</span>' ) ); ?>
					</div><!-- .entry-content -->

					<footer class="entry-meta">
					</footer><!-- .entry-meta -->
				</article><!-- #post -->
		</div><!-- #content -->
	</div><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>
