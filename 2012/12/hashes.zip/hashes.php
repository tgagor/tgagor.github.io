<html>
<head>
<title>Hash List</title>
</head>
<body>
<div id="content">
<h1>Welcome to Hash List!</h1>

<p>This site will feed search engines with hashes of all common passwords :)</p>

<?
$signs = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890`~!@#$%^&*()-=_+[]\\{}|;':\",./<>?";
$howmany = 500;
#$algos = hash_algos();
$algos = array("md5", "sha1");

$index = !isset($_GET['i']) ? 0 : (int)$_GET['i'];
$array_num = !isset($_GET['n']) ? 1 : (int)$_GET['n'];
$array_num = $array_num > 26 ? 25 : $array_num;

function carthezian_set($index, $count=1) {
    global $signs;
    $lists_len = strlen($signs);
    $string = "";
    
    for($i=0; $i<$count; $i++) {
        $r = $index % $lists_len;
        $index = (int)($index / $lists_len);
        $string = $string . $signs[$r];
    }
    
    return $string; 
}

function hash($alg, $pw) {
	if($alg == 'md5') {
		return md5($pw);
	} elseif($alg == 'sha1') {
		return sha1($pw);
	}
}
?>
<h3>Used signs: <?=$signs?></h3>
<h4>Word length: <?=$array_num?></h4>
<h4>Possible passwords: <?=pow(strlen($signs), $array_num)?></h4>

<?if(($index + $howmany) >= pow(strlen($signs), $array_num)):?>
        <a href="?i=0&n=<?=$array_num+1?>">Next &rsaquo;</a>
<?else:?>
        <a href="?i=<?=$index + $howmany?>&n=<?=$array_num?>">Next &rsaquo;</a>
<?endif?>

<table>
<tr>
<th>Password</th>
<?foreach($algos as $alg):?>
<th><?=strtoupper($alg)?> hash of password</th>
<?endforeach?>
</tr>
<?for($i=$index; $i<$index + $howmany; $i++):?>
	<?if($i < pow(strlen($signs), $array_num)):
		$pw = carthezian_set($i, $array_num);?>
		<tr>
		<td><strong><?=$pw?></strong></td>
		<?foreach($algos as $alg):?>
		<td class="hash"><code><?=hash($alg, $pw)?></code></td>
		<?endforeach?>
		</tr>
	<?endif?>
<?endfor?>
</table>

<br />
<?if(($index + $howmany) >= pow(strlen($signs), $array_num)):?>
	<a href="?i=0&n=<?=$array_num+1?>">Next &rsaquo;</a>
<?else:?>
	<a href="?i=<?=$index + $howmany?>&n=<?=$array_num?>">Next &rsaquo;</a>
<?endif?>
</div>
</body>
</html>

